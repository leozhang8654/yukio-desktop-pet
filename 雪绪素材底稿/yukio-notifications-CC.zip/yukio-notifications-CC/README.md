# 雪绪 · 通知动画 CC

- 完成任务 C：展示绿色勾选卡。文件 task-complete.webp / task-complete.gif。
- 对用户提问 C：立起问号卡并指向卡片。文件 question-for-user.webp / question-for-user.gif。

两种主文件都是真正的动画文件，不是静态图集。尺寸 384×416，透明背景，播放一次（loop=1），随后停留在最后画面；可按 192×208 显示。

每段采用 3 个关键帧，时长为 240、240、2800 毫秒。选取几何变化较小的前三帧，避免底下一排生成帧的卡片尺寸与身体变化。没有循环抬手、身体呼吸缩放、跳跃或欢呼。

推荐播放器优先使用动画 WebP：它保留全透明度边缘。GIF 为兼容格式，透明边缘只有二值精度。若播放器不尊重单次循环设置，请按 animations.json 读取 PNG 帧，结束后持续显示 hold.png，直到任务已查看、问题已回答或对应通知被关闭。

每个同名子目录包含：
- frames/00.png、01.png、02.png：完整透明帧，384×416。
- hold.png：最后一帧的稳定提示姿势。
- spritesheet-192.png：一行三格，每格 192×208，供自定义播放器使用；它是静态图集。

preview.html 可离线打开，点击按钮重新播放。animations.json 是播放配置。generation-prompts.json 保存内置 image_gen 生成提示词。

本包只交付动画素材，没有新增宠物，也没有修改当前 Codex 宠物配置或宣称已接入真实通知事件。
